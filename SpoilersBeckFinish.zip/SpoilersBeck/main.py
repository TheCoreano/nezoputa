import sys
import os
import datetime
from serieDAO import *
from spoilerDAO import *

if __name__ == '__main__':
	
	sedao = SerieDAO()
	spdao = SpoilerDAO()
	#spoiler = Spoiler(0,2,"desc",5,"2018-4-09","2018-4-09")
	
	#--- Add
	#spdao.adicionar(spoiler)
	
	#--- Carregar, Alterar e excluir
	#b = spdao.carregar(1)
	#b.descr = "Nova Desc"
	#spdao.alterar(b)
	#spdao.excluir(1)

	#--- Listar
	#spdao.printar()

	#--- Spoiler por serie
	#spdao.printaSS(1)

	while(1):
		op = input("Serie: (1) Adicionar, (2) Listar, (3) Carregar (4) Excluir, (5) Alterar, (6) Exportar, (7) Menu de Spoilers (0) Sair: ")
		if(op == 1):
			print("---------------- Adicionando Serie ----------------")
			nome = ""
			while(nome == ""):
				nome = raw_input("Nome: ")
				sedao.validaNome(nome)
			qtdtemp = 0
			while(qtdtemp < 1):	
				qtdtemp = input("Quantidade temporadas: ")
				sedao.validaTemp(qtdtemp)
			qtdep = 0	
			while(qtdep < 1):	
				qtdep = input("Quantidade episodios: ")
				sedao.validaEp(qtdep)	
			datal = ""
			while(datal == ""):	
				datal = raw_input("Data Lancamento (dd/mm/aaaa): ")
				sedao.validaData(datal)
			s = Serie(0,nome,qtdtemp,qtdep,datal)	
			sedao.adicionar(s)
			print(" >> Adicionada com sucesso" + "\n")
		if(op == 2):
			print("---------------- Listando Series ----------------")
			sedao.printar()
			print(" >> Listado com sucesso" + "\n")
		if(op == 3):
			print("---------------- Carregando Serie ----------------")
			cod = input("Digite o codigo da serie: ")
			serie = sedao.carregar(cod)
			print serie
			print(" >> Carregada com sucesso" + "\n")
		if(op == 4):
			print("---------------- Excluindo Serie ----------------")
			cod = input("Digite o codigo da serie: ")
			sedao.excluir(cod)
			print(" >> Excluida com sucesso" + "\n")
		if(op == 5):
			print("---------------- Alterando Serie ----------------")
			cod = input("Digite o codigo da serie: ")
			s = sedao.carregar(cod)
			print("Serie a ser alterada: " + s.nome + "\n")
			n = raw_input("Novo nome: ")
			temp = raw_input("Nova quantidade de temporadas: ")	
			ep = raw_input("Nova quantidade de episodios: ")
			dl = raw_input("Nova data de lancamento: ")
			if(n != ""): s.nome = n
			if(temp != ""): s.qtdTemp = int(temp)
			if(ep != ""): s.qtdEp = int(ep)
			if(dl != ""): 
				sedao.validaData(dl)
				s.dataL = dl
			sedao.alterar(s)
			print(" >> Alterada com sucesso" + "\n")
		if(op == 6):
			print("---------------- Exportando Serie ----------------")
			cod = input("Digite o codigo da serie: ")
			s = sedao.carregar(cod)
			sedao.exportar(s)
			print(" >> Exportada com sucesso" + "\n")
		if(op == 7):
				while(1):
					print("----->>>>> Menu de Spoilers <<<<<-----")
					op = input("Spoiler: (1) Adicionar, (2) Listar, (3) Carregar (4) Excluir, (5) Alterar, (6) Ver pro serie, (7) Estatisticas (8) Voltar: ")
					if(op == 1):
						print("---------------- Adicionando Spoiler ----------------")
						serie = 0
						while(serie < 1):
							serie = input("Codigo da serie: ")
						desc = ""
						while(desc == ""):
							desc = raw_input("Descricao do spoiler: ")
						ep = 0
						while(ep < 1):
							ep = input("Episodio correspondente: ")
						data = datetime.now()
						dataf = str(data.year) + "-" + str(data.month) + "-" + str(data.day)
						spoiler = Spoiler(0,serie,desc,ep,dataf,dataf)
						spdao.adicionar(spoiler)
						print(" >> Adicionado com sucesso" + "\n")
					if(op == 2):
						print("----------------Listando Spoiler ----------------")
						spdao.printar()
						print(" >> Listados com sucesso" + "\n")
					if(op == 3):
						print("----------------Carregando Spoiler ----------------")
						cod = input("Digite o codigo do spoiler: ")
						s = spdao.carregar(cod)
						print s
						print(" >> Carregado com sucesso" + "\n")
					if(op == 4):
						print("----------------Excluindo Spoiler ----------------")
						cod = input("Digite o codigo do spoiler: ")
						spdao.excluir(cod)
						print(" >> Excluido com sucesso" + "\n")
					if(op == 5):
						print("----------------Alterando Spoiler ----------------")
						cod = input("Digite o codigo do spoiler: ")
						spo = spdao.carregar(cod)
						print("Spoiler a ser alterado: " + spo.descr + "\n")
						se = raw_input("Novo codigo de serie: ")
						d = raw_input("Nova descricao: ")
						e = raw_input("Nova episodio: ")
						if(se != ""): spo.serie = int(se)
						if(d != ""): spo.descr = d
						if(e != ""): spo.ep = e
						data = datetime.now()
						dataf = str(data.year) + "-" + str(data.month) + "-" + str(data.day)
						spo.dataM = dataf
						spdao.alterar(spo)
					if(op == 6):
						print("---------------- Listando por Serie ----------------")
						cod = input("Codigo da serie desejada: ")
						for x in sedao.spoilerSerie(cod):	
							print x
					if(op == 7):
						print("---------------- Estatisticas ----------------")
						maior = Serie()
						menor = Serie()
						for serie in sedao.listar():
							if(len(serie.vetSpoiler) >= len(maior.vetSpoiler)):
								maior = serie
							elif(len(serie.vetSpoiler) <= len(menor.vetSpoiler)):
								menor = serie
						print("Serie com mais spoilers: " + maior.nome + "\n")
						print("Serie com menos spoilers: " + menor.nome + "\n")
					if(op == 8): break;	
						#cod=0,serie=0,descr="",ep=0,dataC="",dataM="")	
		if(op == 0): break;		

