from Serie import *
from Spoiler import *
import os
import psycopg2
from datetime import *


class SerieDAO:
	def adicionar(self, serie):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("INSERT INTO serie(nome, qtdtemp, qtdep, datal) VALUES (%s, %s,%s,%s);", [serie.nome,serie.qtdTemp,serie.qtdEp,serie.dataL])
			conexao.commit()	
		except Exception as e:
			print "Nao foi possivel adicionar a  serie"
		cursor.close()
		conexao.close()

	def excluir(self,cod):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("DELETE from serie where cod = %s;", [cod])
			conexao.commit()	
		except Exception as e:
			print "Nao foi possivel excluir a  serie"
		cursor.close()
		conexao.close()

	def carregar(self, cod):
		serie = Serie()
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM serie WHERE cod = %s", [cod])
			linha = cursor.fetchone()
			d = str(linha[4]).split("-")
			final = str(d[2])+"/"+str(d[1])+"/"+str(d[0])
			serie = Serie(int(linha[0]),linha[1],int(linha[2]),int(linha[3]),final)
		except Exception as e:
			print "Nao foi possivel carregar a  serie"
		cursor.close()
		conexao.close()
		return serie
	
	def alterar(self, serie):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("UPDATE serie SET nome = %s, qtdtemp = %s, qtdep = %s, datal = %s WHERE cod = %s", [serie.nome, serie.qtdTemp, serie.qtdEp,serie.dataL,serie.cod])
			conexao.commit()	
		except Exception as e:
			print "Nao foi possivel alterar a  serie"
		cursor.close()
		conexao.close()

	def listar(self):
		vetObj = []
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM serie")
			vet = cursor.fetchall()			
			for linha in vet:
				d = str(linha[4]).split("-")
				final = str(d[2])+"/"+str(d[1])+"/"+str(d[0])
				vetObj.append(Serie(int(linha[0]),linha[1],int(linha[2]),int(linha[3]),final,self.spoilerSerie(linha[0])))
		except Exception as e:
			print "Nao foi possivel listar as series"
		cursor.close()
		conexao.close()
		return vetObj

	def printar(self):
		a = self.listar()
		for x in a:
			print str(x) + "\n"


	def exportar(self,serie):
		arq = open("series.txt", "a+")
		arq.write(serie.txt())
		arq.close()		

	def validaData(self,data):
		d = data.split("/")
		dia = int(d[0])
		mes = int(d[1])
		ano = int(d[2])
		aux = str(ano)
		if(dia > 1 and mes > 1 and ano > 1900):
			if(len(aux) != 4):
				print("Por favor informe uma data valida! KK")
			elif(mes == 2 and dia > 28): 
				print("Por favor informe uma data valida! YY")
			elif((mes == 1 or mes == 3 or mes == 5 or mes == 7 or mes == 8 or mes == 10 or mes == 12) and dia > 31):
			 print("Por favor informe uma data valida! VVVVV")
			elif((mes == 4 or mes == 6 or mes == 9 or mes == 11) and dia > 30): 
				print("Por favor informe uma data valida!")
			data = str(ano)+"-"+str(mes)+"-"+str(dia)
			return data	
		

	def validaNome(self,nome):
		if(nome == ""):
			print("Insira um nome valido!")

	def validaTemp(self, temp):
		if(temp < 1):
			print("Insira uma quantidade de temporadas valida")

	def validaEp(self,ep):
		if(ep < 1):
			print("Insira uma quantidade de episodios valida")

	def spoilerSerie(self, cod):
		vetObj = []
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM spoiler where codserie = %s", [cod])
			vet = cursor.fetchall()			
			for linha in vet:
				vetObj.append(Spoiler(int(linha[0]),int(linha[1]), linha[2],int(linha[3]), linha[4], linha[5]))
			cursor.close()
			conexao.close()
		except Exception as e:
			print "Rajada, deu um mega pau"
		return vetObj