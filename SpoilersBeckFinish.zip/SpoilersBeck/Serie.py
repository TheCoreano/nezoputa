class Serie:

	def __init__(self,cod = 0,nome = "",qtdTemp="",qtdEp="",dataL="",vetSpoiler=[]):
		self.cod = cod;
		self.nome = nome;
		self.qtdTemp = qtdTemp;
		self.qtdEp = qtdEp;
		self.dataL = dataL;
		self.vetSpoiler = vetSpoiler;

	def __repr__(self):
		return "----------------------" + "\n" + "Codigo: " + str(self.cod) + "\n" + "Nome: " + self.nome + "\n" + "Temporadas: " + str(self.qtdTemp)	+ "\n" + "Episodios: " +str(self.qtdEp) + "\n" + "Data Lancamento: " + str(self.dataL) + "\n";

	def txt(self):
		return 	str(self.cod) + ";" + str(self.nome) + ";" + str(self.qtdTemp) + ";" + str(self.qtdEp) + str(self.dataL)+";\n"