from Spoiler import *
from serieDAO import *
import os
import psycopg2
from datetime import *

class SpoilerDAO:
	def adicionar(self, spoiler):
			try:
				conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
				cursor = conexao.cursor()
				cursor.execute("INSERT INTO spoiler(codserie, descricao, episodio, datac, datam) VALUES (%s,%s,%s,%s,%s);", [spoiler.serie,spoiler.descr,spoiler.ep,spoiler.dataC, spoiler.dataM])
				conexao.commit()	
			except Exception as e:
				print e
			cursor.close()
			conexao.close()

	def carregar(self, cod):
		spoiler = Spoiler()
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM spoiler WHERE cod = %s", [cod])
			linha = cursor.fetchone()
			#self,cod=0,serie=0,descr="",ep=0,dataC="0000-00-00",dataM="0000-00-00"
			spoiler = Spoiler(int(linha[0]), int(linha[1]), linha[2],int(linha[3]), linha[4], linha[5])
		except Exception as e:
			print "Rajada, deu um mega pau"
		cursor.close()
		conexao.close()
		return spoiler		

	def excluir(self,cod):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("DELETE from spoiler where cod = %s;", [cod])
			conexao.commit()	
		except Exception as e:
			print e
		cursor.close()
		conexao.close()

	def alterar(self, spoiler):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("UPDATE spoiler SET descricao = %s, episodio = %s WHERE cod = %s", [spoiler.descr, spoiler.ep,spoiler.cod])
			conexao.commit()	
		except Exception as e:
			print "Rajada, deu um mega pau"
		cursor.close()
		conexao.close()

	def listar(self):
		vetObj = []
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM spoiler")
			vet = cursor.fetchall()			
			for linha in vet:
				vetObj.append(Spoiler(int(linha[0]), int(linha[1]), linha[2],int(linha[3]), linha[4], linha[5]))
		except Exception as e:
			print "Rajada, deu um mega pau"
		cursor.close()
		conexao.close()
		return vetObj

	def printar(self):
		self.forzin(self.listar())
		
	def forzin(self, param):
		for x in param:
			print x

	def validaDesc(self,d):
		if(d == ""):
			print("Insira uma descricao valida!")		