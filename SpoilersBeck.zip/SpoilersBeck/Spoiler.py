from serieDAO import *

class Spoiler:

	def __init__(self,cod=0,serie=0,descr="",ep=0,dataC="",dataM=""):
		self.cod = cod;
		self.serie = serie;
		self.descr= descr;
		self.ep = ep;
		self.dataC  = dataC;
		self.dataM = dataM;

	def __repr__(self):
		d1 = str(self.dataC).split("-")
		cad = d1[2]+"/"+d1[1]+"/"+d1[0]
		d2 = str(self.dataM).split("-")
		mod = d2[2]+"/"+d2[1]+"/"+d2[0]
		return "----------------------" + "\n" + "Codigo: " + str(self.cod) + "\n" + "\n" + "Descricao: " + self.descr	+ "\n" + "Episodio: " +str(self.ep) + "\n" + "Data Cadastro: " + str(cad) + "\n" + "Data Modificacao: " + str(mod);
			