
drop table spoiler;
drop table serie;



create table serie(
    cod serial primary key,
    nome text not null,
    qtdTemp integer not null,
    qtdEp integer not null,
    dataL date not null
  );

create table spoiler(
    cod serial primary key,
    codSerie integer references serie(cod) ON DELETE CASCADE ON UPDATE CASCADE,
    descricao text not null,
    episodio integer not null,
    dataC date default current_date,
    dataM date
);
