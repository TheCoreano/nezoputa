import sys
import os
from serieDAO import *

if __name__ == '__main__':
	
	sedao = SerieDAO()
	#sedao.adicionar(Serie("Coomeia",2,13,"2012-3-10"))
	comea = Serie("Coommeia",3,15,"2012-4-10")
	#sedao.adicionar(comea)