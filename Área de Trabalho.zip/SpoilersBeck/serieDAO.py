from Serie import *
import os
import psycopg2
from datetime import *


class SerieDAO():
	def adicionar(self, serie):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=postgres")
			cursor = conexao.cursor()
			cursor.execute("INSERT INTO serie(nome, qtdtemp, qtdep, datal) VALUES (%s, %s,%s,%s);", [serie.nome,serie.qtdTemp,serie.qtdEp,serie.dataL])
			conexao.commit()	
		except Exception as e:
			print "Rajada, deu um mega pau"
		cursor.close()
		conexao.close()

	def alterar(self, serie):
		try:
			conexao = psycopg2.connect("dbname=spoilers host=localhost user=postgres password=postgres")
			cursor = conexao.cursor()
			cursor.execute("UPDATE serie SET nome = %s,qtdtemp = %s, qtdep = %s, datal = %s) VALUES (%s, %s,%s,%s);", [serie.nome,serie.qtdTemp,serie.qtdEp,serie.dataL])
			conexao.commit()	
		except Exception as e:
			print "Rajada, deu um mega pau"
		cursor.close()
		conexao.close()