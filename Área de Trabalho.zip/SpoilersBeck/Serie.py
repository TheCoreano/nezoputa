class Serie:

	def __init__(self,nome,qtdTemp,qtdEp,dataL,vetSpoiler=[]):
		self.nome = nome;
		self.qtdTemp = qtdTemp;
		self.qtdEp = qtdEp;
		self.dataL = dataL;
		self.vetSpoiler = vetSpoiler;

	def __repr__(self):
		return self.nome + "\n" + self.qtdTemp	+ "\n" + self.qtdEp + "\n" + self.dataL;	