class Spoiler:

	def __init__(self,cod,desc,ep,dataC,dataM,serie):
		self.cod = cod;
		self.desc= desc;
		self.ep = ep;
		self.dataC  = dataC;
		self.dataM = dataM;
		self.serie = serie;

	def __repr__(self):
		return self.cod + "\n" + self.desc	+ "\n" + self.ep + "\n" + self.dataC + self.dataM;