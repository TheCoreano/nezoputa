class Serie:
	def __init__(self,id,nome,quantidadeTemporadas,quantidadeEpisodios,dataLancamento):
		self.id = id
		self.nome = nome
		self.quantidadeTemporadas = quantidadeTemporadas
		self.quantidadeEpisodios = quantidadeEpisodios
		self.dataLancamento = dataLancamento
	def __toString__(self):
		print "\nID: "+str(self.id)+"\nNome: "+str(self.nome)+"\nNumero de Temporadas: "+str(self.quantidadeTemporadas)+"\nNumero de Ep.: "+str(self.quantidadeEpisodios)+"\nData Lancamento: "+self.dataLancamento.strftime("%d/%m/%y")
class Spoiler:
	def __init__(self,id,idSerie,descricao,episodio,dataDeCadastro,dataDaUltimaAtt):
		self.id = id
		self.idSerie = idSerie
		self.descricao = descricao
		self.episodio = episodio
		self.dataDeCadastro = dataDeCadastro
		self.dataDaUltimaAtt = dataDaUltimaAtt
	def __toString__(self):
		print "\nID: "+str(self.id)+"\nID da Serie: "+str(self.idSerie)+"\nDescricao: "+self.descricao+"\nNumero de Episodio: "+str(self.episodio)+"\nData de Cadastro: "+self.dataDeCadastro.strftime("%d/%m/%y")+"\nData da Ultima Att.: "+self.dataDaUltimaAtt.strftime("%d/%m/%y")