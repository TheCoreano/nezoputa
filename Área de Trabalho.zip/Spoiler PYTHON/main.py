# -*- coding: utf-8 -*-
from daos import SerieDAO
from daos import SpoilerDAO
if __name__ == "__main__":
	serieDAO = SerieDAO()
	spoilerDAO = SpoilerDAO()
	print("###############################################")
	print("############### Spoilers PYTHON ###############")
	print("###############################################")
	print("# Digite (0) para sair do aplicativo          #")
	print("# Digite (1) para visualizar todas as series  #")
	print("# Digite (2) para adicionar nova serie        #")
	print("# Digite (3) para deletar uma serie           #")
	print("# Digite (4) para editar  uma serie           #")
	print("# Digite (5) para visualizar spoilers         #")
	print("# Digite (6) para adicionar um spoiler        #")
	print("# Digite (7) para deletar um spoiler          #")
	print("# Digite (8) para alterar um spoiler          #")
	print("# Digite (9) para exportar para o backup.txt  #")
	print("# Digite (10) receber estatisticas            #")
	print("###############################################")
	entradaValor = -1
	while entradaValor!=0:
		entradaValor = input(">> Selecione uma opcao: ")
		if (entradaValor == 0):
			print ">> Obrigado por utilizar nosso sistema"
			break
		elif (entradaValor == 1):
			serieDAO.printarLista()
		elif (entradaValor == 2):
			serieDAO.adicionar()
		elif (entradaValor == 3):
			serieDAO.excluir()
		elif (entradaValor == 4):
			serieDAO.editar()
		elif(entradaValor == 5):
			spoilerDAO.printarLista()
		elif(entradaValor == 6):
			spoilerDAO.adicionar()
		elif(entradaValor == 7):
			spoilerDAO.excluir()
		elif(entradaValor == 8):
			spoilerDAO.alterar()
		elif(entradaValor == 9):
			serieDAO.exportar()
		elif(entradaValor == 10):
			serieDAO.estatisticas()
		else:
			print "\n>> Selecione uma opcao valida\n"