CREATE TABLE "serie"(
  id serial unique,
  nome varchar(80) not null,
  "quantidadeTemporadas" smallint not null,
  "quantidadeEpisodios" smallint not null,
  "dataLancamento" date not null
);
CREATE TABLE "spoiler"(
  "idSpoiler" SERIAL,
	"idSerie" SMALLINT NOT NULL,
	descricao TEXT NOT NULL,
	episodio SMALLINT NOT NULL,
	"dataCadastro" DATE NOT NULL,
  "dataUltimaAtt" DATE NOT NULL,
  CONSTRAINT "idSerieFK" FOREIGN KEY("idSerie") REFERENCES serie(id)
);