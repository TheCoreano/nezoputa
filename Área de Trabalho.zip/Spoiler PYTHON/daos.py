import psycopg2
from models import Serie
from models import Spoiler
from datetime import *
import sys
class SerieDAO:
	def carregarLista(self):
		listaSeries = []
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM SERIE")
			vet = cursor.fetchall()
			for serieAtual in vet:
				serieAdd = Serie(serieAtual[0],serieAtual[1],serieAtual[2],serieAtual[3],serieAtual[4])	
				listaSeries.append(serieAdd)
		except Exception as e:
			print "Ocorreu um erro ao tentar conectar em sua DATABASE \n"
		cursor.close()
		conexao.close()
		return listaSeries
	def printarLista(self):
		meuVet = self.carregarLista()
		print("# Todas series cadastradas ate o momento      #")
		for serieAtual in meuVet:
			print("-----------------------------------------------")
			serieAtual.__toString__();
			print("\n-----------------------------------------------\n")
	def adicionar(self):
		listaSeries = self.carregarLista()
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()
			valoresValidos = False
			while (not valoresValidos):
				valoresValidos = True
				try:
					nomeDaSerie = raw_input(">> Digite o NOME da serie(MAX.80 CARACTERES): ")
					numeroTemporadas = input(">> Digite o NUMERO DE TEMPORADAS da serie(MAX.50 TEMPORADAS): ")
					numeroDeEpisodios = input(">> Digite o NUMERO DE EPISODIOS da serie(MAX.2000 EPISODIOS): ")
					dataLancamento = raw_input(">> Digite a DATA DE LANCAMENTO da serie(FORMATO: DD/MM/YY): ")
					dataConvertida = 0
				except Exception as e:
					print "Por favor insira valores validos! "+str(e)
					valoresValidos = False
					pass
				if ((len(nomeDaSerie)>80 or len(nomeDaSerie)<=0) or (numeroTemporadas > 50 or numeroTemporadas <= 0) 
					or (numeroDeEpisodios<=0 or numeroDeEpisodios>= 2000)):
					valoresValidos = False
					print "\n>> Insira valores validos! \n"
					break
				else:
					try:
						dataLancamento = dataLancamento.split("/")
						dataConvertida = date(int(dataLancamento[2]),int(dataLancamento[1]),int(dataLancamento[0]))
					except Exception as e:
						print "\nData inserida invalida! \n"
						valoresValidos = False
						pass
			valorParaInserir = [nomeDaSerie,numeroTemporadas,numeroDeEpisodios,dataConvertida]
			cursor.execute("INSERT INTO SERIE(nome,\"quantidadeTemporadas\",\"quantidadeEpisodios\",\"dataLancamento\") VALUES(%s,%s,%s,%s);", valorParaInserir)
			conexao.commit()
			cursor.close()
			conexao.close()
			print "\n>> Serie adicionada com sucesso!\n"

		except Exception as e:
			print "\n>> Ocorreu um erro ao tenter conectar em sua DATABASE \n"+str(e)

	def excluir(self):
		listaSeries = self.carregarLista()
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()
			valoresValidos = False
			while(not valoresValidos):
				valoresValidos = True
				try:
					serieEncontrada = False
					idSerie = input(">> Digite o [ID] da Serie que deseja excluir, ou digite [-1] para sair: ")
					if (idSerie != -1):
						for serieAtual in listaSeries:
							if ( serieAtual.id == idSerie):
								serieEncontrada = True
								break

						if (not serieEncontrada):
							print "\n>> Nao existe nenhuma Serie com o [ID] inserido!\n"
							valueValidos = False
						else:
							cursor.execute("DELETE FROM SPOILER WHERE \"idSerie\" = %s",[idSerie])
							cursor.execute("DELETE FROM SERIE WHERE id = %s",[idSerie])
							conexao.commit()
							print "\n>> Serie deletada com sucesso!\n"

				except Exception as erro:
					print ">> Por favor digite um [ID] valido!"+str(erro)
					valoresValidos = False
					pass

			cursor.close()
			conexao.close()
		except Exception as e:
			print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)

	def editar(self):
		listaSeries = self.carregarLista()
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()
			valoresValidos = False
			while (not valoresValidos):
				valoresValidos = True
				serieEncontrada = False
				try:
					idSerie = input(">> Digite o [ID] da Serie que deseja editar, ou digite -1 para sair: ")
					for serieAtual in listaSeries:
						if (idSerie == serieAtual.id):
							serieEncontrada = True
							break
				except Exception as erro:
					print ">> Por favor digite valores validos! \n"+str(erro)
				if (not serieEncontrada):
					valoresValidos = True
					print "\n>> Nao existe nenhuma serie com o [ID] inserido\n"
					break
				else:
					try:
						nomeDaSerie = raw_input(">> Digite o novo NOME da serie(MAX.80 CARACTERES): ")
						numeroTemporadas = input(">> Digite o novo NUMERO DE TEMPORADAS da serie(MAX.50 TEMPORADAS): ")
						numeroDeEpisodios = input(">> Digite o novo NUMERO DE EPISODIOS da serie(MAX.2000 EPISODIOS): ")
						dataLancamento = raw_input(">> Digite a nova DATA DE LANCAMENTO da serie(FORMATO: DD/MM/YY): ")
						dataConvertida = 0
						if ((len(nomeDaSerie)>80 or len(nomeDaSerie)<=0) or (numeroTemporadas > 50 or numeroTemporadas <= 0) or (numeroDeEpisodios<=0 or numeroDeEpisodios>= 2000)):
							valoresValidos = False
							print "\n>> Insira valores validos! \n"
							break
						else:
							try:
								dataLancamento = dataLancamento.split("/")
								dataConvertida = date(int(dataLancamento[2]),int(dataLancamento[1]),int(dataLancamento[0]))
							except Exception as erro3:
								print "\nData inserida invalida! \n"+str(erro3)
								valoresValidos = False
								pass

					except Exception as erro2:
						print "Por favor insira valores validos! "+str(erro2)
						valoresValidos = False
						pass
					if (valoresValidos):
						valDatas = [nomeDaSerie, numeroTemporadas, numeroDeEpisodios, dataConvertida, idSerie]
						cursor.execute("UPDATE SERIE SET NOME = %s, \"quantidadeTemporadas\" = %s, \"quantidadeEpisodios\" = %s, \"dataLancamento\" = %s WHERE id = %s ",valDatas)
						conexao.commit()
						print "\n>> Serie Atualizada com sucesso!\n"

			cursor.close()
			conexao.close()
		except Exception as e:
			print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)
		
	def exportar(self):
		arquivoTxt = open("backup.txt","w")
		listaDeSeries = self.carregarLista()
		for serieAtual in listaDeSeries:
			arquivoTxt.write(str(serieAtual.id)+";"+serieAtual.nome+";"+str(serieAtual.quantidadeTemporadas)+";"+str(serieAtual.quantidadeEpisodios)+";"+serieAtual.dataLancamento.strftime("%d/%m/%y")+"\n")
		arquivoTxt.close()
		print "\n >> Series exportadas com sucesso << \n"

	def estatisticas(self):
		listaSeries = self.carregarLista()
		listaSpoilers = SpoilerDAO().carregarLista()
		maioresSpoilers = []
		menoresSpoilers = []
		maxValue = -99999
		minValue = +99999
		conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
		cursor = conexao.cursor()
		if len(listaSpoilers)>0:
			if len(listaSeries)>0:
				for serieAtual in listaSeries:
					cursor.execute("SELECT * FROM SPOILER WHERE \"idSerie\" = %s",[serieAtual.id])
					numeroDeSpoilers = int(cursor.rowcount)
					if (numeroDeSpoilers>=maxValue):
						if(numeroDeSpoilers>maxValue): maioresSpoilers = []
						maioresSpoilers.append(serieAtual)
						maxValue = numeroDeSpoilers
					if(numeroDeSpoilers<=minValue):
						if(menoresSpoilers<minValue): menoresSpoilers = []
						menoresSpoilers.append(serieAtual)
						minValue = numeroDeSpoilers
			else:
				print "\n>> Nenhuma serie cadastrada ate o momento <<\n"
			print("-----------------------------------------------")
			print("- Serie(s) com maior(es) num(s) de spoiler(s) -")
			print(">> Quantidade de spoilers: "+str(maxValue)+" <<")
			for serieAtual in maioresSpoilers:
				print ">> "+serieAtual.nome

			print("\n-----------------------------------------------\n")
			print("-----------------------------------------------")
			print("- Serie(s) com menor(es) num(s) de spoiler(s) -")
			print(">> Quantidade de spoilers: "+str(minValue)+" <<")
			for serieAtual in menoresSpoilers:
				print ">> "+serieAtual.nome
			print("\n-----------------------------------------------\n")
		else:
			print "\n>> Nenhum spoiler cadastrado ate o momento <<\n"
		cursor.close()
		conexao.close()

class SpoilerDAO:
	def carregarLista(self):
		listaSpoilers = []
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()
			cursor.execute("SELECT * FROM SPOILER");
			vet = cursor.fetchall()
			for spoilerAtual in vet:
				spoilerAdd = Spoiler(spoilerAtual[0],spoilerAtual[1],spoilerAtual[2],spoilerAtual[3],spoilerAtual[4],spoilerAtual[5])
				listaSpoilers.append(spoilerAdd)
			conexao.close()
			cursor.close()
		except Exception as e:
			print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)
		return listaSpoilers
	def printarLista(self):
		serieDAO = SerieDAO()
		listaDeSeries = serieDAO.carregarLista()
		try:
			idSerie = 0
			serieEncontrada = False
			serieFinal = 0
			while(not serieEncontrada):
				idSerie = input(">> Digite o [ID] da serie que deseja visualizar os spoilers: ")
				for serieAtual in listaDeSeries:
					if (serieAtual.id == idSerie ):
						serieEncontrada = True
						serieFinal = serieAtual
						break
				if(idSerie == -1):
					break

			if(serieEncontrada):
				listaSpoilers = self.carregarLista()
				listaFinal = []
				for spoilerAtual in listaSpoilers:
					if (spoilerAtual.idSerie == idSerie):
						listaFinal.append(spoilerAtual)
				print("# Todas spoilers da serie "+serieFinal.nome+" #")
				for spoilerAtual in listaFinal:
					print("-----------------------------------------------")
					spoilerAtual.__toString__();
					print("\n-----------------------------------------------\n")

		except Exception as e:
			print "\n>> Por favor insira um valor valido para [ID]!\n"+str(e)
	def adicionar(self):
		serieDAO = SerieDAO()
		listaDeSeries = serieDAO.carregarLista()
		
		serieEncontrada = False
		serieFinal = 0
		while(not serieEncontrada):
			try:
				idSerie = input(">> Digite o [ID] da serie que o spoiler pertence: ")
				for serieAtual in listaDeSeries:
					if serieAtual.id == idSerie:
						serieEncontrada = True
						serieFinal = serieAtual 
						break
				if(not serieEncontrada):
					print ">> A serie que voce informou nao foi encotnrada em nosso BD! <<"		
			except Exception as e:
				print "\n>> Por favor insira um valor valido para [ID]!\n"+str(e)
				pass
		epInvalido = True
		while(epInvalido):
			try: 
				epSpoiler = input(">> Digite o numero do episodio do spoiler: ")
				if ( epSpoiler > 0 and epSpoiler <= serieFinal.quantidadeEpisodios ):
					epInvalido = False
				if(epInvalido):
					print ">> O episodio que voce informou nao esta disponivel nessa serie <<"
			except Exception as e:
				print "\n>> Por favor insira um valido valido para EPISODIO <<\n"+str(e)
				pass
		valoresValidos = False
		while(not valoresValidos):
			valoresValidos = True
			try:
				descricao = raw_input(">> Digite a descricao do spoiler: ")
				dataDeCadastro = datetime.now().date()
			except Exception as e:
				valoresValidos = False
				print "\n>> Por favor insira valores validos! <<\n"+str(e)
				pass
		try:
			conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
			cursor = conexao.cursor()

			vetValoresToAdd = [idSerie,descricao,epSpoiler,dataDeCadastro,dataDeCadastro]
			cursor.execute("INSERT INTO SPOILER(\"idSerie\",descricao,episodio,\"dataCadastro\",\"dataUltimaAtt\") VALUES(%s,%s,%s,%s,%s)",vetValoresToAdd)
			conexao.commit()

			print "\n>> Spoiler cadastrado com sucesso na serie: "+serieFinal.nome+" <<\n"

			cursor.close()
			conexao.close()
		except Exception as e:
			print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)
		
	def excluir(self):
		listaSpoilers = self.carregarLista()
		try:
			spoilerEncontrado = False
			while(not spoilerEncontrado):
				idSpoiler = input(">> Digite o [ID] do spoiler que deseja deletar ou -1 para sair: ")
				if idSpoiler == -1:
					break
				else:
					for spoilerAtual in listaSpoilers:
						if(spoilerAtual.id == spoilerAtual.id):
							spoilerEncontrado = True
							break
				if(not spoilerEncontrado and idSpoiler != -1):
					print "\n>> O id que voce digito nao foi encontrado em nosso BD <<\n"
			if(spoilerEncontrado):
				try:
					conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
					cursor = conexao.cursor()

					cursor.execute("DELETE FROM SPOILER WHERE \"idSerie\" = %s",[idSpoiler])
					print "\n>> Serie deletada com sucesso << \n"
					conexao.commit()

					cursor.close()
					conexao.close()
				except Exception as e:
					print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)
		except Exception as e:
			print "\n>> Por favor insira um valor valido para [ID]!\n"+str(e)
			pass
	def alterar(self):
		serieDAO = SerieDAO()
		listaSpoilers = self.carregarLista()
		listaDeSeries = serieDAO.carregarLista()
		spoilerEncontrado = False
		while(not spoilerEncontrado):
			idSpoiler = input("Digite o [ID] do spoiler que deseja modificar ou -1 para sair: ")
			if ( idSpoiler == -1 ):
				break
			else:
				for spoilerAtual in listaSpoilers:
					if (spoilerAtual.id == idSpoiler ):
						spoilerEncontrado = True
						break
		if(spoilerEncontrado):
			serieEncontrada = False
			serieFinal = 0
			while(not serieEncontrada):
				try:
					idSerie = input(">> Digite o novo [ID] da serie que o spoiler pertence: ")
					for serieAtual in listaDeSeries:
						if serieAtual.id == idSerie:
							serieEncontrada = True
							serieFinal = serieAtual 
							break
					if(not serieEncontrada):
						print ">> A serie que voce informou nao foi encotnrada em nosso BD! <<"		
				except Exception as e:
					print "\n>> Por favor insira um valor valido para [ID]!\n"+str(e)
					pass
			epInvalido = True
			while(epInvalido):
				try: 
					epSpoiler = input(">> Digite o novo numero do episodio do spoiler: ")
					if ( epSpoiler > 0 and epSpoiler <= serieFinal.quantidadeEpisodios ):
						epInvalido = False
					if(epInvalido):
						print ">> O episodio que voce informou nao esta disponivel nessa serie <<"
				except Exception as e:
					print "\n>> Por favor insira um valido valido para EPISODIO <<\n"+str(e)
					pass
			valoresValidos = False
			while(not valoresValidos):
				valoresValidos = True
				try:
					descricao = raw_input(">> Digite a nova descricao do spoiler: ")
					dataUltimaAtt = datetime.now().date()
				except Exception as e:
					valoresValidos = False
					print "\n>> Por favor insira valores validos! <<\n"+str(e)
					pass
			try:
				conexao = psycopg2.connect("dbname=spoilersPy user=postgres password=admin")
				cursor = conexao.cursor()

				vetValoresToAdd = [idSerie,descricao,epSpoiler,dataUltimaAtt,idSpoiler]
				cursor.execute("UPDATE SPOILER SET \"idSerie\" = %s, descricao = %s, \"episodio\" = %s, \"dataUltimaAtt\" = %s WHERE \"idSpoiler\" = %s ",vetValoresToAdd)
				conexao.commit()

				print "\n>> Spoiler atualizado com sucesso na serie: "+serieFinal.nome+" <<\n"

				cursor.close()
				conexao.close()
			except Exception as e:
				print "\n>> Ocorreu um erro ao tentar conectar em sua DATABASE! \n"+str(e)